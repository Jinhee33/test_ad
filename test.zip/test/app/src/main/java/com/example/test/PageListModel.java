package com.example.test;

import java.util.List;

public class PageListModel {
    public long id;
    public long totalResults;
    public List<ItemModel> articles;
}
